package ksk

import (
	"fmt"

	"github.com/gocolly/colly/v2"
	// "github.com/gocolly/colly/v2/extensions"
)

type kskArtistWork struct {
	Artist     string
	Url        string
	TotalWorks string
	WorkSlice  []string
}

// func DeSerializeJson(fn string) kskMetaData {
// 	data := kskMetaData{}
// 	file, err := os.ReadFile(fn)
// 	if err != nil {
// 		fmt.Println("heree!")
// 		log.Fatal(err.Error())
// 	}
// 	err = json.Unmarshal(file, &data)
// 	if err != nil {
// 		fmt.Println("heree8888")
// 		log.Fatal(err.Error())
// 	}
// 	return data
// }

// func jsonify(val kskMetaData, dir string, name string) {
// 	// fmt.Println(val)
// 	res, err := json.MarshalIndent(val, "", "    ")
// 	if err != nil {
// 		log.Fatalln(err)
// 	}
// 	dir = "dmetadata/" + dir
// 	name = dir + "/" + name
// 	err = os.Mkdir(dir, 0750)
// 	if err != nil && !os.IsExist(err) {
// 		fmt.Printf("ERROR: skipping %s already exist\n", dir)
// 	}
// 	os.WriteFile(name, res, 0644)
// }

type KskMetaData struct {
	Title          string
	Artist         string
	Artists        []string
	Circle         string
	Magazine       string
	Parody         string
	Tags           []string
	Pages          string
	OfficialSource string
}

func ScrapeMetadata() {
	// durl := "https://ksk.moe/archive/10509/fingertip-temptation"

	// urlList := DeSerializeJson("metadata/urls.json")
	// metadata := kskMetaData{}
	c := colly.NewCollector(
	// colly.CacheDir("./.ksk_metadata"),
	)
	// urlList := DeSerializeJson("metadata/urls.json")
	// c.Limit(&colly.LimitRule{
	// 	Parallelism: 2,
	// })
	c.OnRequest(func(r *colly.Request) {
		fmt.Println("Scraping:", r.URL.String())
	})
	// c.OnHTML("section[id='metadata']", func(oh *colly.HTMLElement) {
	// 	md := kskMetaData{}
	// 	title := oh.ChildText("h1")
	// 	md.Title = title
	// 	divs := oh.DOM.Find("#metadata > div")
	// 	divs.Each(func(i int, s *goquery.Selection) {
	// 		key := s.Find("strong").Text()
	// 		key = strings.ToLower(key)
	// 		val := s.Find("a span")
	// 		switch key {
	// 		case "artist":
	// 			md.Artist = val.Text()
	// 		case "artists":
	// 			fmt.Println(val)
	// 			artists := []string{}
	// 			val.Each(func(i int, ts *goquery.Selection) {
	// 				artists = append(artists, ts.Text())
	// 			})
	// 			md.Artists = artists
	// 		case "circle":
	// 			md.Circle = val.Text()
	// 		case "magazine":
	// 			md.Magazine = val.Text()
	// 		case "parody":
	// 			md.Parody = val.Text()
	// 		case "tags":
	// 			tags := []string{}
	// 			val.Each(func(i int, ts *goquery.Selection) {
	// 				tags = append(tags, ts.Text())
	// 			})
	// 			md.Tags = tags
	// 		case "pages":
	// 			md.Pages = val.Text()
	// 		case "official source":
	// 			md.OfficialSource = val.Text()
	// 		}
	// 	})
	// 	var dir string
	// 	if md.Artists != nil {
	// 		dir = strings.Join(md.Artists, " ")
	// 	} else {
	// 		dir = md.Artist
	// 	}
	// 	name := strings.TrimSpace(md.Title) + ".json"
	// 	jsonify(md, dir, name)
	// })

	// for _, url := range urlList {
	// 	c.Visit(url)
	// }
}

// func MergeData() {
// 	foo := DeSerializeJson("metadata.json")
// 	bar := "https://ksk.moe"
// 	for i := range foo {
// 			if foo[i]["Url"] == bar {
// 				fmt.Println("found it")
// 		}
// 	}
// }

// func Foo() {
// 	results := []kskArtistWork{}
// 	data := DeSerializeJson("page2.json")
// 	baseURL := "https://ksk.moe"
// 	page2 := []string{}
//
// 	c := colly.NewCollector(
// 		colly.CacheDir("./ksk_cache"),
// 		// colly.Async(true),
// 	)
// 	extensions.RandomUserAgent(c)
// 	// c.Limit(&colly.LimitRule{
// 	// 	Parallelism: 2,
// 	// })
// 	c.OnRequest(func(r *colly.Request) {
// 		fmt.Println("Visiting", r.URL.String())
// 	})
// 	// tw := false
// 	c.OnHTML("main[id='tag']", func(con *colly.HTMLElement) {
// 		//  := kskArtistWork{}
// 		// .artist = artist
// 		// .url = artistURL
// 		// .totalWorks = totalWorks
// 		workSlice := []string{}
// 		con.ForEach("section[id='archives'] > main > article", func(count int, articles *colly.HTMLElement) {
// 			work := articles.ChildAttr("a", "href")
// 			workSlice = append(workSlice, baseURL+work)
// 		})
// 		nav := con.ChildTexts("section[id='archives'] > footer > nav[class='pagination']")
// 		if nav != nil {
// 			urll := fmt.Sprintf("%v", con.Request.URL)
// 			page2 = append(page2, urll)
// 		}
// 		results = append(results)
// 		con.Request.Ctx.Put("workSlice", workSlice)
// 	})
//
// 	for id := range data {
// 		res := kskArtistWork{}
// 		// res.Artist = data[id]["artist"]
// 		res.Url = data[id]
// 		// res.TotalWorks = data[id]["total_works"]
// 		c.OnScraped(func(r *colly.Response) {
// 			myValue := r.Ctx.GetAny("workSlice")
// 			res.WorkSlice = myValue
// 		})
// 		pt := "/page/2"
// 		secondPageURL := fmt.Sprintf("%v%s", res.Url, pt)
// 		// c.Visit(secondPageURL)
// 		c.Visit(secondPageURL)
// 		results = append(results, res)
// 	}
// 	jsonify(results, "final88.json")
// 	jsonify(page2, "page2ss.json")
// }

// func MergeWorks() {
// 	data := DeSerializeJson("metadata/incomplete_metadata.json")
// 	links := make([]string, 0)
// 	for _, m := range data {
// 		// Check if the "doo" key exists in the map
// 		if val, ok := m["WorkSlice"]; ok {
// 			// fmt.Println(reflect.TypeOf(val))
// 			// Check if the value of "doo" is a slice of strings
// 			if strSlice, ok := val.([]interface{}); ok {
// 				for _, value := range strSlice {
// 					if url, ok := value.(string); ok {
// 						links = append(links, url)
// 					}
// 				}
// 			}
// 		}
// 	}
// 	// for _, val := range links {
// 	// 	fmt.Println(val)
// 	// }
// 	jsonify(links, "metadata/urls.json")
//
