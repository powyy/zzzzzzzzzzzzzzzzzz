package main

import (
	"encoding/json"
	"fmt"
	ksk "ksk/pkg"
	"log"
	"os"
)

func main() {
	Segregate()
	// Output: key value
	// key2 does not exist
	// ksk.ScrapeMetadata()
	// foo := ksk.DeSerializeJson()
	// for i := range foo {
	// 	fmt.Println(foo[i]["url"])
	// }
}

func Segregate() {
	dirs, err := os.ReadDir("dmetadata")
	if err != nil {
		log.Println(err.Error())
	}
	for _, val := range dirs {
		if val.IsDir() {
			d := "dmetadata/" + val.Name()
			files, err := os.ReadDir(d)
			if err != nil {
				log.Println(err.Error())
			}
			for _, f := range files {
				fn := d + "/" + f.Name()
				data, err := os.ReadFile(fn)
				if err != nil {
					fmt.Println(err.Error())
				}
				md := ksk.KskMetaData{}
				json.Unmarshal(data, &md)
				title := md.Title
				dir := "metadata/clean/"
				if md.Artists != nil {
					dir = "metadata/unclean/"
				}
				dir = dir + title + ".json"
				jsonify(&md, dir)
			}
		}
	}
}

func jsonify(val *ksk.KskMetaData, name string) {
	res, err := json.MarshalIndent(val, "", "    ")
	if err != nil {
		log.Fatalln(err)
	}
	os.WriteFile(name, res, 0644)
	return
}
